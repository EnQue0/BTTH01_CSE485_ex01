<?php
    $arr1 = [1, 'B', 'C', 'E'];
    $lowercaseArr1 = array_map(function($item1) {
        if (is_string($item1)) {
            return strtolower($item1);
        } elseif (is_int($item1)) {
            return (string) $item1;
        } else {
            return $item1;
        }
    }, $arr1);
    $arr2 = ['a', 0, null, false];
    $lowercaseArr2 = array_map(function($item2) {
        if(is_string(($item2))){
            return strtolower($item2);
        }elseif (is_int($item2)){
            return (string) $item2;
        }elseif (is_null($item2)) {
            return 'null';
        }elseif ($item2 == false){
            return 'false';
        }else{
            return $item2;
        }
        },$arr2);
    print_r($lowercaseArr1);
    print_r($lowercaseArr2);
?>