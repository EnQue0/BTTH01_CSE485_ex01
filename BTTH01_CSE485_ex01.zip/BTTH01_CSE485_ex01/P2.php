<?php
$arrs = ['đỏ', 'xanh', 'cam', 'trắng'];
$names = ['Anh', 'Sơn', 'Thắng', 'tôi'];

$result = '';

$count = count($arrs);
for ($i = 0; $i < $count; $i++) {
    $color = $arrs[$i];
    $name = $names[$i];
    
    if ($name == 'Sơn') {
        $result .= "$color là màu yêu thích của $name, ";
    } else {
        $result .= "Màu $color là màu yêu thích của $name, ";
    }
}

$result .= 'còn màu yêu thích của tôi là màu trắng';

echo $result;
?>