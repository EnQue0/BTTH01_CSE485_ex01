<?php
    function performArrayOperations($arr) {
        $sum = 0;
        $difference = 0;
        $product = 1;
        $quotient = 0;
     
        foreach ($arr as $value) {
           $sum += $value;
           $difference -= $value;
           $product *= $value;
           $quotient = ($quotient === 0) ? $value : $quotient / $value;
        }
     
        echo "Sum: " . $sum . "<br>";
        echo "Difference: " . $difference . "<br>";
        echo "Product: " . $product . "<br>";
        echo "Quotient: " . $quotient . "<br>";
     }
     
     $numbers = [2, 5, 6, 9, 2, 5, 6, 12 ,5];
     performArrayOperations($numbers);
?>