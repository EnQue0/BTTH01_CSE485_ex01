<?php
    $numbers = ['key1' => 12,'key2' => 30,'key3' => 4,'key4' => -123,'key5' => 1234,'key6' => -12565,];
    $firstElement = reset($numbers);
    $lastElement = end($numbers);
    $minValues = min($numbers);
    $maxValues = max($numbers);
    $sumValues = array_sum($numbers);

    echo "
    Giá trị đầu là $firstElement, 
    Giá trị cuối là $lastElement,
    Giá trị nhỏ nhất là $minValues, 
    Giá trị lớn nhất là $maxValues, 
    Tổng các giá trị từ mảng là $sumValues";

    sort($numbers);
    print_r($numbers);
    
    rsort($numbers);
    print_r($numbers);
    
    ksort($numbers);
    print_r($numbers);
    
    krsort($numbers);
    print_r($numbers);
    ?>