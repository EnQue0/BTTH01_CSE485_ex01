<?php
    $arr1 = [1, 'b', 'c', 'd'];
    $uppercaseArr1 = array_map(function($item1){
        if (is_string($item1)){
            return strtoupper($item1);
        }elseif (is_int($item1)){
            return (string) $item1;
        }else{
            return $item1;
        }
    },$arr1);
    $arr2 = ['a', 0, null, false];
    $uppercaseArr2 = array_map(function($item2){
        if (is_string($item2)){
            return strtoupper($item2);
        }elseif (is_int($item2)){
            return (string) $item2;
        }elseif(is_null($item2)){
            return 'NULL';
        }elseif($item2 == false){
            return 'FALSE';
        }
        else{
            return $item2;
        }
    },$arr2);
    print_r($uppercaseArr1);
    print_r($uppercaseArr2);
?>